"""
rostaing-ocr: Package OCR puissant pour extraction de texte optimisé RAG/LLM
Version: 2.0.0
"""

from .rostaing_ocr import ocr_extractor

__version__ = "2.0.0"
__author__ = "Rostaing"
__all__ = ["ocr_extractor"]